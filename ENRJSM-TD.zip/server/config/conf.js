module.exports = {
    ks:'ertDFTdftrgfER45erhgfdwr654refdERRTGFD',
}